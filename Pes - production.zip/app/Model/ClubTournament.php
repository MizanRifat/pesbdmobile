<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ClubTournament extends Model
{
    protected $table = 'club_tournament';
}
