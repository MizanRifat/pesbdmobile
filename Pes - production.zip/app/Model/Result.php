<?php

namespace App\Model;
use App\Http\Support\Database\CacheQueryBuilder;
use Illuminate\Database\Eloquent\Model;

class Result extends Model
{
    use CacheQueryBuilder;
    
    
}
