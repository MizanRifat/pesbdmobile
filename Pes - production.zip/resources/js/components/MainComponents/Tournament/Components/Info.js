import React from 'react'

export default function Info() {
    return (
        <div>
            
        </div>
    )
}
