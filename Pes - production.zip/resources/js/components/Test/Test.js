import React from 'react'
import Ajax from './Ajax'
import Checkbox from './Checkbox'
import AdminLayout2 from './AdminLayout2'

export default function Test() {
  return (
    <div>
      <Checkbox />
      {/* <Ajax /> */}
      {/* <Bulk /> */}
      {/* <AdminLayout2 /> */}

    </div>
  )
}
