const types = {
    1:'user registered',
    2:'club created',
    3:'player model request',
    4:'team model request',

    5:'welocome to new user',
    6:'added to a tournament',
    7:'added as tournament official',
    8:'tournament fixture finalized',
    9:'match result approved',
    10:'requested player added',
    11:'requested team added',
    12:'pre-season mode open',
    13:'pre-season mode close',

    14:'match result submitted',
    15:'match result rejected',
    16:'club approval request',
    17:'club approved',
}

const columns = [
    'id','sender_id','receiver_id','type','seen','href'
]